import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// =====================================================================================
//  Portrait of a Boy — real-time head renderer
//  Skin: pre-integrated subsurface scattering + dual-lobe specular + procedural pores
//  Eyes: refractive cornea, procedural iris, soft-box catchlights
//  Hair: ~55k strands, Marschner-style shading, deep-opacity shadows
//  Image: progressive temporal accumulation (soft shadows, AA, stochastic hair coverage)
// =====================================================================================

const qs = new URLSearchParams(location.search);
const DEG = Math.PI / 180;
const $ = (id) => document.getElementById(id);
const isSmall = Math.min(screen.width, screen.height) < 700 || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
const SHOT = qs.has('shot');

// ------------------------------------------------------------------ renderer
const canvas = $('c');
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: SHOT });
} catch (e) {
  showError('WebGL 2 is not available in this browser, so the 3D portrait cannot be shown.');
  throw e;
}
const PR = Math.min(window.devicePixelRatio || 1, isSmall ? 1.5 : 2);
renderer.setPixelRatio(PR);
renderer.setSize(innerWidth, innerHeight, false);
const TONEMAP = { agx: THREE.AgXToneMapping, aces: THREE.ACESFilmicToneMapping, neutral: THREE.NeutralToneMapping };
renderer.toneMapping = TONEMAP[qs.get('tm') || 'agx'];
renderer.toneMappingExposure = 1.0;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const camera = new THREE.PerspectiveCamera(24, innerWidth / innerHeight, 0.02, 20);
const TARGET = new THREE.Vector3(0, 0.495, 0.035);
const HOME = { yaw: 24, pitch: 4, dist: 0.8 };
function homeDistance() {
  const aspect = innerWidth / innerHeight;
  // keep ~0.34 m of head+hair visible vertically and ~0.30 m horizontally
  const vfov = 24 * DEG;
  const dv = 0.17 / Math.tan(vfov / 2);
  const hfov = 2 * Math.atan(Math.tan(vfov / 2) * aspect);
  const dh = 0.15 / Math.tan(hfov / 2);
  return Math.min(1.3, Math.max(dv, dh));
}
HOME.dist = homeDistance();
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true; controls.dampingFactor = 0.085;
controls.minDistance = SHOT ? 0.03 : 0.2; controls.maxDistance = 1.35;
controls.minPolarAngle = 58 * DEG; controls.maxPolarAngle = 108 * DEG;
controls.enablePan = false; controls.rotateSpeed = 0.7; controls.zoomSpeed = 0.8;
controls.autoRotateSpeed = 0.9;
function placeCamera(yaw, pitch, dist, tx = 0, ty = TARGET.y, tz = TARGET.z) {
  controls.target.set(tx, ty, tz);
  const y = yaw * DEG, p = pitch * DEG;
  camera.position.set(tx + dist * Math.sin(y) * Math.cos(p), ty + dist * Math.sin(p), tz + dist * Math.cos(y) * Math.cos(p));
  camera.lookAt(controls.target);
  controls.update();
}
placeCamera(HOME.yaw, HOME.pitch, HOME.dist);
const scene = new THREE.Scene();

// ------------------------------------------------------------------ backdrop (drawn in-scene)
const BG = { uBgA: { value: new THREE.Vector3() }, uBgB: { value: new THREE.Vector3() }, uBgCenter: { value: new THREE.Vector2(0.5, 0.56) }, uRes: { value: new THREE.Vector2(1, 1) } };
const BG_GLSL = /* glsl */`
uniform vec3 uBgA; uniform vec3 uBgB; uniform vec2 uBgCenter; uniform vec2 uRes;
vec3 bgColor() {
  vec2 uv = gl_FragCoord.xy / uRes;
  vec2 d = (uv - uBgCenter) * vec2(uRes.x / uRes.y, 1.0);
  float r = length(d * vec2(0.8, 1.0));
  return mix(uBgA, uBgB, smoothstep(0.0, 0.75, r));
}`;
const bgMat = new THREE.ShaderMaterial({
  uniforms: BG,
  vertexShader: 'void main(){ gl_Position = vec4(position.xy, 0.9999, 1.0); }',
  fragmentShader: `${BG_GLSL}\nvoid main(){ gl_FragColor = vec4(bgColor(), 1.0); }`,
  depthWrite: false, depthTest: false, toneMapped: false,
});
const triGeo = new THREE.BufferGeometry();
triGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
const bgMesh = new THREE.Mesh(triGeo, bgMat); bgMesh.frustumCulled = false; bgMesh.renderOrder = -10;
scene.add(bgMesh);

// ------------------------------------------------------------------ lighting presets
// az: degrees from the face direction (+z) toward the model's left (+x); el: degrees up.
const PRESETS = {
  studio: {
    label: 'Studio', exposure: 0.88,
    sky: [0.022, 0.022, 0.025], horizon: [0.014, 0.013, 0.013], ground: [0.006, 0.0055, 0.005],
    boxes: [
      { az: 78, el: 5, w: 30, h: 40, c: [0.12, 0.123, 0.135] },
      { az: 180, el: 40, w: 20, h: 12, c: [0.30, 0.31, 0.34] },
      { az: 0, el: 70, w: 30, h: 30, c: [0.03, 0.03, 0.032] },
    ],
    key: { az: -22, el: 26, size: 9, c: [4.4, 4.2, 4.0] },
    rim: { az: 140, el: 35, c: [1.8, 1.85, 2.0] },
    bg: [[0.050, 0.052, 0.058], [0.005, 0.0053, 0.0062]],
  },
  window: {
    label: 'Window', exposure: 1.05,
    sky: [0.045, 0.043, 0.040], horizon: [0.030, 0.027, 0.023], ground: [0.012, 0.010, 0.008],
    boxes: [
      { az: 95, el: 0, w: 45, h: 35, c: [0.085, 0.075, 0.062] },
      { az: -10, el: -30, w: 40, h: 20, c: [0.05, 0.045, 0.04] },
    ],
    key: { az: -68, el: 14, size: 20, c: [3.2, 3.4, 3.8] },
    rim: { az: 160, el: 20, c: [0.25, 0.25, 0.27] },
    bg: [[0.070, 0.066, 0.060], [0.009, 0.008, 0.0075]],
  },
  chiaroscuro: {
    label: 'Chiaroscuro', exposure: 1.0,
    sky: [0.004, 0.0038, 0.0035], horizon: [0.003, 0.0027, 0.0024], ground: [0.0015, 0.0013, 0.0012],
    boxes: [
      { az: 60, el: 10, w: 25, h: 30, c: [0.012, 0.010, 0.008] },
    ],
    key: { az: -55, el: 38, size: 4.5, c: [5.6, 4.7, 3.6] },
    rim: { az: 150, el: 30, c: [0.35, 0.3, 0.25] },
    bg: [[0.030, 0.024, 0.018], [0.0022, 0.0018, 0.0015]],
  },
  backlight: {
    label: 'Backlight', exposure: 1.0,
    sky: [0.015, 0.016, 0.019], horizon: [0.010, 0.010, 0.012], ground: [0.004, 0.004, 0.0045],
    boxes: [
      { az: 25, el: 8, w: 28, h: 34, c: [0.20, 0.19, 0.18] },
      { az: -120, el: 20, w: 16, h: 30, c: [0.35, 0.37, 0.42] },
    ],
    key: { az: 128, el: 28, size: 8, c: [5.0, 5.3, 6.0] },
    rim: { az: -135, el: 25, c: [1.6, 1.7, 1.9] },
    bg: [[0.040, 0.046, 0.058], [0.004, 0.0045, 0.0058]],
  },
};
function dirAE(az, el) {
  const a = az * DEG, e = el * DEG;
  return new THREE.Vector3(Math.sin(a) * Math.cos(e), Math.sin(e), Math.cos(a) * Math.cos(e));
}
function smooth(a, b, x) { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); }
function buildEnvironment(preset, keyOnly = false) {
  const W = 1024, H = 512;
  const data = new Float32Array(W * H * 4);
  let src = preset.boxes;
  if (keyOnly) {
    const k = preset.key, t = Math.tan(k.size * DEG);
    const Lr = Math.PI / (4 * t * t);
    src = [{ az: k.az, el: k.el, w: k.size, h: k.size, c: k.c.map(v => v * Lr) }];
  }
  const boxes = src.map(b => {
    const c = dirAE(b.az, b.el);
    const up0 = Math.abs(c.y) > 0.95 ? new THREE.Vector3(0, 0, 1) : new THREE.Vector3(0, 1, 0);
    const r = new THREE.Vector3().crossVectors(up0, c).normalize();
    const u = new THREE.Vector3().crossVectors(c, r).normalize();
    return { cx: c.x, cy: c.y, cz: c.z, rx: r.x, ry: r.y, rz: r.z, ux: u.x, uy: u.y, uz: u.z, tw: Math.tan(b.w * DEG), th: Math.tan(b.h * DEG), col: b.c };
  });
  const sh = new Float64Array(27);
  for (let j = 0; j < H; j++) {
    const lat = ((j + 0.5) / H - 0.5) * Math.PI;
    const cl = Math.cos(lat), sl = Math.sin(lat);
    const dO = (2 * Math.PI / W) * (Math.PI / H) * cl;
    for (let i = 0; i < W; i++) {
      const a = ((i + 0.5) / W - 0.5) * 2 * Math.PI;
      const dx = Math.cos(a) * cl, dy = sl, dz = Math.sin(a) * cl;
      let c0, c1, c2;
      if (keyOnly) { c0 = c1 = c2 = 0; }
      else if (dy > 0) { const t = Math.pow(dy, 0.6); c0 = preset.horizon[0] + (preset.sky[0] - preset.horizon[0]) * t; c1 = preset.horizon[1] + (preset.sky[1] - preset.horizon[1]) * t; c2 = preset.horizon[2] + (preset.sky[2] - preset.horizon[2]) * t; }
      else { const t = Math.min(1, -dy * 4); c0 = preset.horizon[0] + (preset.ground[0] - preset.horizon[0]) * t; c1 = preset.horizon[1] + (preset.ground[1] - preset.horizon[1]) * t; c2 = preset.horizon[2] + (preset.ground[2] - preset.horizon[2]) * t; }
      for (const b of boxes) {
        const cd = dx * b.cx + dy * b.cy + dz * b.cz;
        if (cd <= 0.05) continue;
        const x = (dx * b.rx + dy * b.ry + dz * b.rz) / cd / b.tw, y = (dx * b.ux + dy * b.uy + dz * b.uz) / cd / b.th;
        const ax = Math.abs(x), ay = Math.abs(y);
        if (ax > 1.1 || ay > 1.1) continue;
        const m = keyOnly ? smooth(1.03, 0.97, ax) * smooth(1.03, 0.97, ay) : smooth(1.1, 0.92, ax) * smooth(1.1, 0.92, ay);
        const f = keyOnly ? 1 - 0.1 * (x * x + y * y) : 1 - 0.25 * (x * x + y * y);
        c0 += b.col[0] * m * f; c1 += b.col[1] * m * f; c2 += b.col[2] * m * f;
      }
      const o = (j * W + i) * 4;
      data[o] = c0; data[o + 1] = c1; data[o + 2] = c2; data[o + 3] = 1;
      if (!keyOnly) {
        const Y = [0.282095, 0.488603 * dy, 0.488603 * dz, 0.488603 * dx, 1.092548 * dx * dy, 1.092548 * dy * dz, 0.315392 * (3 * dz * dz - 1), 1.092548 * dx * dz, 0.546274 * (dx * dx - dy * dy)];
        for (let k = 0; k < 9; k++) { const w = Y[k] * dO; sh[k * 3] += c0 * w; sh[k * 3 + 1] += c1 * w; sh[k * 3 + 2] += c2 * w; }
      }
    }
  }
  const A = [1, 2 / 3, 2 / 3, 2 / 3, 1 / 4, 1 / 4, 1 / 4, 1 / 4, 1 / 4];
  const Cb = [0.282095, 0.488603, 0.488603, 0.488603, 1.092548, 1.092548, 0.315392, 1.092548, 0.546274];
  const shc = Array.from({ length: 9 }, (_, k) => new THREE.Vector3(sh[k * 3] * A[k] * Cb[k], sh[k * 3 + 1] * A[k] * Cb[k], sh[k * 3 + 2] * A[k] * Cb[k]));
  const tex = new THREE.DataTexture(data, W, H, THREE.RGBAFormat, THREE.FloatType);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.LinearSRGBColorSpace;
  tex.magFilter = THREE.LinearFilter; tex.minFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  const pm = new THREE.PMREMGenerator(renderer);
  const rt = pm.fromEquirectangular(tex);
  pm.dispose(); tex.dispose();
  return { pmrem: rt.texture, sh: shc };
}

// ------------------------------------------------------------------ shared uniforms
const U = {
  uKeyDir: { value: new THREE.Vector3() }, uKeyColor: { value: new THREE.Vector3() }, uKeyTan: { value: 0.2 },
  uRimDir: { value: new THREE.Vector3() }, uRimColor: { value: new THREE.Vector3() },
  uSH: { value: Array.from({ length: 9 }, () => new THREE.Vector3()) },
  uEnv: { value: null }, uEnvKey: { value: null }, uEnvSpec: { value: 1.0 }, uEnvDiff: { value: 1.0 },
  uShadowRaw: { value: null }, uShadowCmp: { value: null }, uHairShadow: { value: null }, uShadowMat: { value: new THREE.Matrix4() },
  uShadowP: { value: new THREE.Vector4() }, uShadowRot: { value: new THREE.Matrix3() },
  uDetail: { value: null }, uDetailScale: { value: 48.0 }, uDetailAmt: { value: 1.0 },
  uLUT: { value: null }, uFrame: { value: 0 }, uCurvScale: { value: parseFloat(qs.get('curv') || '1.6') },
};
Object.assign(U, BG);
const FLOAT_RT = renderer.extensions.has('EXT_color_buffer_float');
let ENV_DEFINES = null;
function envDefines(tex) {
  const h = tex.image.height;
  const maxMip = Math.log2(h) - 2;
  const d = { ENVMAP_TYPE_CUBE_UV: '', CUBEUV_TEXEL_WIDTH: 1.0 / (3 * Math.max(Math.pow(2, maxMip), 7 * 16)), CUBEUV_TEXEL_HEIGHT: 1.0 / h, CUBEUV_MAX_MIP: maxMip.toFixed(1) };
  if (!FLOAT_RT) d.SHADOW_PACKED = '';
  return d;
}

// ------------------------------------------------------------------ GLSL common
const GLSL_COMMON = /* glsl */`
#define PI 3.141592653589793
uniform vec3 uKeyDir; uniform vec3 uKeyColor; uniform float uKeyTan;
uniform vec3 uRimDir; uniform vec3 uRimColor;
uniform vec3 uSH[9];
uniform sampler2D uEnv; uniform sampler2D uEnvKey; uniform float uEnvSpec; uniform float uEnvDiff;
uniform float uFrame;
uniform sampler2D uShadowRaw; uniform sampler2DShadow uShadowCmp; uniform sampler2D uHairShadow; uniform mat4 uShadowMat; uniform vec4 uShadowP;
uniform mat3 uShadowRot;
#include <cube_uv_reflection_fragment>
#include <packing>
vec3 shIrr(vec3 n) {
  return uSH[0] + uSH[1]*n.y + uSH[2]*n.z + uSH[3]*n.x + uSH[4]*(n.x*n.y) + uSH[5]*(n.y*n.z) + uSH[6]*(3.0*n.z*n.z-1.0) + uSH[7]*(n.x*n.z) + uSH[8]*(n.x*n.x-n.y*n.y);
}
float D_GGX(float NoH, float a) { float a2 = a*a; float d = NoH*NoH*(a2-1.0)+1.0; return a2/(PI*d*d); }
float V_Smith(float NoV, float NoL, float a) { float gv = NoL*(NoV*(1.0-a)+a); float gl = NoV*(NoL*(1.0-a)+a); return 0.5/max(gv+gl, 1e-5); }
float F_Schlick(float f0, float VoH) { float f = pow(1.0-VoH, 5.0); return f0 + (1.0-f0)*f; }
float specSphere(vec3 N, vec3 V, vec3 L, float rough, float f0, float tanR) {
  float a = rough*rough; float a2 = clamp(a + 0.5*tanR, 0.0, 1.0);
  vec3 H = normalize(V+L);
  float NoL = max(dot(N,L),0.0), NoV = max(dot(N,V),0.03), NoH = max(dot(N,H),0.0), VoH = max(dot(V,H),0.0);
  return D_GGX(NoH, a2) * V_Smith(NoV, NoL, a2) * F_Schlick(f0, VoH) * NoL;
}
vec2 envBRDF(float rough, float NoV) {
  const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022);
  const vec4 c1 = vec4(1.0, 0.0425, 1.04, -0.04);
  vec4 r = rough*c0 + c1;
  float a004 = min(r.x*r.x, exp2(-9.28*NoV))*r.x + r.y;
  return vec2(-1.04, 1.04)*a004 + r.zw;
}
vec3 envSpecular(vec3 N, vec3 V, float rough, float f0) {
  vec3 R = reflect(-V, N);
  R = normalize(mix(R, N, rough*rough));
  vec3 pre = textureCubeUV(uEnv, R, rough).rgb;
  vec2 ab = envBRDF(rough, max(dot(N,V),1e-4));
  return pre * (f0*ab.x + ab.y);
}
// reflections that head back into the skull are blocked by the head itself (sphere approximation)
vec3 headOut(vec3 wp) { return normalize(wp - vec3(0.0, clamp(wp.y, 0.43, 0.55), 0.02)); }
float headEnvOcc(vec3 wp, vec3 N, vec3 V) {
  return smoothstep(-0.35, 0.15, dot(reflect(-V, N), headOut(wp)));
}
float ign(vec2 p) { p += uFrame * 5.588238; return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
const vec2 PD[16] = vec2[16](
  vec2(-0.94201624,-0.39906216), vec2(0.94558609,-0.76890725), vec2(-0.09418410,-0.92938870), vec2(0.34495938,0.29387760),
  vec2(-0.91588581,0.45771432), vec2(-0.81544232,-0.87912464), vec2(-0.38277543,0.27676845), vec2(0.97484398,0.75648379),
  vec2(0.44323325,-0.97511554), vec2(0.53742981,-0.47373420), vec2(-0.26496911,-0.41893023), vec2(0.79197514,0.19090188),
  vec2(-0.24188840,0.99706507), vec2(-0.81409955,0.91437590), vec2(0.19984126,0.78641367), vec2(0.14383161,-0.14100790));
float rawDepth(vec2 uv) {
#ifdef SHADOW_PACKED
  return unpackRGBAToDepth(texture2D(uShadowRaw, uv));
#else
  return texture2D(uShadowRaw, uv).x;
#endif
}
// PCSS soft shadow from the key light + deep-opacity hair transmittance. returns (opaque vis, hair T)
vec2 keyShadow(vec3 wp, vec3 n, float soft) {
  vec3 p = wp + n * uShadowP.w * 1.5;
  vec4 s = uShadowMat * vec4(p, 1.0);
  vec3 sc = s.xyz / s.w;
  if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return vec2(1.0);
  vec3 nl = uShadowRot * n;
  float W = uShadowP.w / uShadowP.x;
  vec2 dzduv = clamp(nl.xy * W / (max(nl.z, 0.25) * uShadowP.z), -8.0, 8.0);
  float z = sc.z - 0.00006;
  float ang = ign(gl_FragCoord.xy) * 6.2831853;
  mat2 rot = mat2(cos(ang), sin(ang), -sin(ang), cos(ang));
  float searchR = uShadowP.y * (0.025 / uShadowP.z);
  float bsum = 0.0, bn = 0.0;
  for (int i = 0; i < 16; i++) {
    vec2 o = rot * PD[i] * searchR;
    float zr = z + dot(dzduv, o);
    float d = rawDepth(sc.xy + o);
    if (d < zr - 0.0001) { bsum += zr - d; bn += 1.0; }
  }
  float vis = 1.0;
  if (bn > 0.5) {
    float dz = bsum / bn;
    float pen = clamp(dz * uShadowP.y * soft, uShadowP.x * 1.0, searchR);
    float lit = 0.0;
    for (int i = 0; i < 16; i++) {
      vec2 o = rot * PD[i] * pen;
      lit += texture(uShadowCmp, vec3(sc.xy + o, z + dot(dzduv, o)));
    }
    vis = lit / 16.0;
  }
  // hair: soft deep-opacity transmittance, filter radius grows with distance to the hair layer
  float dh0 = texture2D(uHairShadow, sc.xy).x;
  float dzh = max(0.0, z - dh0) * uShadowP.z;
  float hr = clamp(dzh * uShadowP.y / uShadowP.z * 1.0, uShadowP.x * 6.0, uShadowP.x * 24.0);
  float T = 0.0;
  for (int i = 0; i < 12; i++) {
    vec2 o = rot * PD[i] * hr;
    float dh = texture2D(uHairShadow, sc.xy + o).x;
    T += exp(-420.0 * max(0.0, z + dot(dzduv, o) - dh) * uShadowP.z);
  }
  T /= 12.0;
  return vec2(vis, T);
}
// cheaper variant for hair fragments (heavy overdraw)
vec2 keyShadowLite(vec3 wp, vec3 n) {
  vec3 p = wp + n * uShadowP.w * 2.0;
  vec4 s = uShadowMat * vec4(p, 1.0);
  vec3 sc = s.xyz / s.w;
  if (sc.x < 0.0 || sc.x > 1.0 || sc.y < 0.0 || sc.y > 1.0 || sc.z > 1.0) return vec2(1.0);
  float z = sc.z - 0.0002;
  float ang = ign(gl_FragCoord.xy) * 6.2831853;
  mat2 rot = mat2(cos(ang), sin(ang), -sin(ang), cos(ang));
  float r = uShadowP.x * 5.0;
  float lit = 0.0, T = 0.0;
  for (int i = 0; i < 4; i++) {
    vec2 o = rot * PD[i * 4 + 1] * r;
    lit += texture(uShadowCmp, vec3(sc.xy + o, z));
    float dh = texture2D(uHairShadow, sc.xy + o * 0.6).x;
    T += exp(-700.0 * max(0.0, z - dh) * uShadowP.z);
  }
  return vec2(lit * 0.25, T * 0.25);
}
`;

// ------------------------------------------------------------------ skin material
const SKIN_VS = /* glsl */`
attribute vec3 nsmooth; attribute vec3 albedo; attribute vec4 attrA; attribute vec4 attrB;
varying vec3 vWPos; varying vec3 vN; varying vec3 vNs; varying vec3 vAlb; varying vec3 vObj; varying vec4 vA; varying vec4 vB;
void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWPos = wp.xyz; vObj = position;
  vN = normalize(mat3(modelMatrix) * normal);
  vNs = normalize(mat3(modelMatrix) * nsmooth);
  vAlb = pow(albedo, vec3(2.2));
  vA = attrA; vB = attrB;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const SKIN_FS = /* glsl */`
${GLSL_COMMON}
${BG_GLSL}
uniform sampler2D uDetail; uniform float uDetailScale; uniform float uDetailAmt;
uniform sampler2D uLUT; uniform float uCurvScale;
varying vec3 vWPos; varying vec3 vN; varying vec3 vNs; varying vec3 vAlb; varying vec3 vObj; varying vec4 vA; varying vec4 vB;
float h31(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float vn3(vec3 p) { vec3 i = floor(p); vec3 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(h31(i), h31(i + vec3(1,0,0)), f.x), mix(h31(i + vec3(0,1,0)), h31(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(h31(i + vec3(0,0,1)), h31(i + vec3(1,0,1)), f.x), mix(h31(i + vec3(0,1,1)), h31(i + vec3(1,1,1)), f.x), f.y), f.z); }
float neckFade(vec3 p) {
  float fp = dot(p - vec3(0.0, 0.335, 0.07), normalize(vec3(0.0, 1.0, 0.217)));
  return smoothstep(0.0, 0.05, fp);
}
float blob(vec3 p, vec3 c, float r, vec3 s) { vec3 d = (p - c) / (r * s); return exp(-0.5 * dot(d, d)); }
float oiliness(vec3 p) {
  float t = blob(p, vec3(0.0, 0.545, 0.12), 0.018, vec3(1.8, 1.0, 1.0));
  t = max(t, blob(p, vec3(0.0, 0.49, 0.145), 0.012, vec3(0.8, 1.6, 1.0)));
  t = max(t, 0.6 * blob(p, vec3(0.0, 0.418, 0.125), 0.01, vec3(1.0)));
  return clamp(t, 0.0, 1.0);
}
vec3 tnormal(vec2 uv, float amt, out float cav) {
  vec4 t = texture2D(uDetail, uv);
  cav = t.a;
  return vec3((t.xy * 2.0 - 1.0) * amt, 1.0);
}
vec3 triplanar(vec3 p, vec3 n, float amt, out float cav) {
  vec3 w = pow(abs(n), vec3(4.0)); w /= (w.x + w.y + w.z);
  float c1, c2, c3;
  vec3 tx = tnormal(p.zy * uDetailScale, amt, c1);
  vec3 ty = tnormal(p.xz * uDetailScale + 0.31, amt, c2);
  vec3 tz = tnormal(p.xy * uDetailScale + 0.67, amt, c3);
  cav = c1 * w.x + c2 * w.y + c3 * w.z;
  tx = vec3(tx.xy + n.zy, abs(tx.z) * n.x);
  ty = vec3(ty.xy + n.xz, abs(ty.z) * n.y);
  tz = vec3(tz.xy + n.xy, abs(tz.z) * n.z);
  return normalize(tx.zyx * w.x + ty.xzy * w.y + tz.xyz * w.z);
}
vec3 lutDiffuse(float ndl, float curv) {
  float v = sqrt(clamp(curv / 0.5, 0.0, 1.0));
  vec3 s = texture2D(uLUT, vec2(ndl * 0.5 + 0.5, 1.0 - v)).rgb;
  return s * s;
}
void main() {
  vec3 N = normalize(vN);
  vec3 Ns = normalize(vNs);
  vec3 V = normalize(cameraPosition - vWPos);
  float ao = vA.x, lip = vA.y, hocc = vA.z, scalp = vA.w;
  float wet = vB.x, ear = vB.y, curv = vB.z * 0.4 * uCurvScale;
  float oil = oiliness(vObj);
  float cav;
  vec3 Nd = triplanar(vObj, N, uDetailAmt * (1.0 - 0.75 * lip), cav);
  if (lip > 0.01) {
    float g = sin(vObj.x * 2600.0 + (sin(vObj.y * 900.0 + vObj.x * 300.0) * 0.6 + sin(vObj.x * 1700.0) * 0.4) * 1.5);
    vec3 tx = normalize(cross(vec3(0.0, 1.0, 0.0), N));
    Nd = normalize(Nd + tx * smoothstep(0.55, 1.0, abs(g)) * sign(g) * 0.10 * lip);
    cav *= 1.0 - 0.15 * lip * smoothstep(0.7, 1.0, abs(g));
  }
  vec3 albedo = vAlb * mix(0.90, 1.0, cav);
  float m1 = vn3(vObj * 260.0) * 0.6 + vn3(vObj * 620.0) * 0.4;
  float m2 = vn3(vObj * 1500.0 + 7.0);
  albedo *= mix(vec3(1.06, 0.97, 0.96), vec3(0.95, 1.02, 1.03), m1) * (0.97 + 0.06 * m2);
  vec3 Nr = normalize(mix(Ns, N, 0.35));
  vec3 Ng = normalize(mix(N, Nd, 0.35));
  vec3 Nb = normalize(mix(N, Nd, 0.75));
  vec3 L = normalize(uKeyDir);
  vec2 sh = keyShadow(vWPos, N, 1.0);
  float vis = sh.x * sh.y;
  vec3 visC = pow(vec3(sh.x), vec3(0.72, 0.96, 1.0)) * pow(vec3(sh.y), vec3(0.9, 0.98, 1.0));
  vec3 dk = vec3(lutDiffuse(dot(Nr, L), curv).r, lutDiffuse(dot(Ng, L), curv).g, lutDiffuse(dot(Nb, L), curv).b);
  vec3 diff = uKeyColor * dk * visC;
  vec3 Lr = normalize(uRimDir);
  vec3 hOut = headOut(vWPos);
  float rimOcc = smoothstep(-0.05, 0.3, dot(Ns, Lr)) * smoothstep(-0.25, 0.2, dot(hOut, Lr));
  diff += uRimColor * max(dot(Ng, Lr), 0.0) * ao * hocc * rimOcc;
  vec3 amb = vec3(shIrr(Nr).r, shIrr(Ng).g, shIrr(Nb).b) * uEnvDiff;
  diff += amb * vec3(pow(ao, 0.6), pow(ao, 0.9), ao) * hocc;
  vec3 trans = (uKeyColor * max(dot(-Ns, L), 0.0) * sh.x * 0.2 + uRimColor * max(dot(-Ns, Lr), 0.0)) * vec3(0.85, 0.22, 0.09) * ear * 0.08;
  vec3 color = albedo * (diff + trans);
  float rough1 = mix(mix(mix(0.50, 0.38, oil), 0.32, lip), 0.12, wet), rough2 = mix(mix(mix(0.30, 0.21, oil), 0.16, lip), 0.06, wet);
  vec3 dnx = dFdx(Nd), dny = dFdy(Nd);
  float kvar = min(0.5 * (dot(dnx, dnx) + dot(dny, dny)), 0.2);
  rough1 = sqrt(sqrt(rough1 * rough1 * rough1 * rough1 + kvar));
  rough2 = sqrt(sqrt(rough2 * rough2 * rough2 * rough2 + kvar));
  float f0 = 0.028;
  float specOcc = clamp(pow(ao, 1.5) * mix(0.6, 1.0, cav), 0.0, 1.0) * hocc;
  float w2 = mix(mix(0.15, 0.35, lip), 0.6, wet);
  float ks = mix(specSphere(Nd, V, L, rough1, f0, uKeyTan), specSphere(Nd, V, L, rough2, f0, uKeyTan), w2);
  float kr = mix(specSphere(Nd, V, Lr, rough1, f0, 0.05), specSphere(Nd, V, Lr, rough2, f0, 0.05), 0.18);
  float gz = smoothstep(0.02, 0.25, dot(N, V));
  float keyOcc = smoothstep(-0.12, 0.2, dot(Ns, L)) * smoothstep(-0.3, 0.1, dot(hOut, L));
  vec3 spec = PI * (uKeyColor * min(ks, 6.0) * vis * keyOcc * mix(0.5, 1.0, cav) * mix(specOcc, 1.0, 0.35) + uRimColor * min(kr, 3.0) * ao * ao * hocc * gz * rimOcc);
  spec += (envSpecular(Nd, V, rough1, f0) * (1.0 - w2) + envSpecular(Nd, V, rough2, f0) * w2) * uEnvSpec * specOcc * headEnvOcc(vWPos, Nd, V);
  color += spec;
  color = min(color, vec3(64.0));
  if (any(isnan(color))) color = vec3(0.0);
  float nf = neckFade(vObj);
  color = mix(bgColor(), color, nf * nf);
  gl_FragColor = vec4(color, 1.0);
}`;

// ------------------------------------------------------------------ eye material
const EYE_VS = /* glsl */`
attribute vec3 eyelocal; attribute float eyeao;
varying vec3 vWPos; varying vec3 vL; varying float vAO;
void main() {
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWPos = wp.xyz; vL = eyelocal; vAO = eyeao;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
const EYE_FS = /* glsl */`
${GLSL_COMMON}
uniform mat3 uEyeRot;
uniform float uZcc; uniform float uRL; uniform float uIrisZ; uniform float uPupil;
uniform sampler2D uIris;
varying vec3 vWPos; varying vec3 vL; varying float vAO;
void main() {
  vec3 lp = vL;
  float ao = clamp(vAO, 0.0, 1.0);
  vec3 Vw = normalize(cameraPosition - vWPos);
  mat3 toLocal = transpose(uEyeRot);
  vec3 V = toLocal * Vw;
  vec3 L = toLocal * normalize(uKeyDir);
  vec3 Lr = toLocal * normalize(uRimDir);
  float rho = length(lp.xy);
  float isCornea = step(0.0, lp.z) * (1.0 - smoothstep(uRL - 0.0002, uRL + 0.0004, rho));
  vec3 Nsc = normalize(lp);
  vec3 Nco = normalize(lp - vec3(0.0, 0.0, uZcc));
  vec3 Nl = normalize(mix(Nsc, Nco, isCornea));
  vec3 Nw = uEyeRot * Nl;
  vec2 sh = keyShadow(vWPos, Nw, 0.6);
  float vis = sh.x * sh.y;
  vec3 Rf = refract(-V, Nco, 1.0 / 1.376);
  float t = (uIrisZ - lp.z) / min(Rf.z, -1e-3);
  vec3 ip = lp + Rf * t;
  float ir = length(ip.xy);
  vec3 irisC = texture2D(uIris, ip.xy / (2.0 * uRL) + 0.5).rgb;
  irisC *= smoothstep(uPupil, uPupil + 0.00018, ir);
  vec3 In = normalize(vec3(-ip.xy * 0.25 / uRL, 1.0));
  float caus = 1.0 + 0.5 * pow(max(dot(normalize(ip.xy + 1e-6), -normalize(L.xy + 1e-6)), 0.0), 2.0) * smoothstep(0.0, 0.5, L.z) * smoothstep(0.2 * uRL, uRL, ir);
  vec3 irisLight = uKeyColor * max(dot(In, L), 0.0) * caus * vis + shIrr(uEyeRot * In) * uEnvDiff * 0.8 * ao;
  vec3 sclera = vec3(0.56, 0.51, 0.47);
  float corner = smoothstep(0.30, 0.95, abs(lp.x) / 0.0123);
  float angA = atan(lp.y, lp.x);
  float polar = acos(clamp(lp.z / length(lp), -1.0, 1.0));
  float wv = sin(angA * 23.0 + sin(polar * 40.0 + angA * 7.0) * 1.3) * 0.5 + sin(angA * 51.0 + polar * 25.0) * 0.5;
  float vein = smoothstep(0.93, 1.0, abs(wv)) * smoothstep(0.55, 1.1, polar) * (0.35 + 0.65 * corner);
  sclera = mix(sclera, vec3(0.60, 0.40, 0.36), corner * 0.35);
  sclera = mix(sclera, vec3(0.45, 0.13, 0.11), vein * 0.55);
  sclera *= mix(0.82, 1.0, smoothstep(uRL, uRL + 0.0022, rho));
  float rimEye = smoothstep(-0.1, 0.2, Lr.z);
  vec3 scl = sclera * (uKeyColor * max(dot(Nsc, L) * 0.8 + 0.2, 0.0) * vis + (shIrr(uEyeRot * Nsc) * uEnvDiff + uRimColor * max(dot(Nsc, Lr), 0.0) * rimEye) * ao);
  float limb = smoothstep(uRL - 0.0006, uRL + 0.0003, ir);
  vec3 col = mix(scl, mix(irisC * irisLight, scl, limb), isCornea);
  float rough = mix(0.08, 0.03, isCornea);
  vec3 dnx = dFdx(Nw), dny = dFdy(Nw);
  rough = sqrt(sqrt(rough * rough * rough * rough + min(0.5 * (dot(dnx, dnx) + dot(dny, dny)), 0.2)));
  float f0 = 0.025;
  vec2 abk = envBRDF(rough, max(dot(Nw, Vw), 1e-4));
  vec3 spec = textureCubeUV(uEnvKey, reflect(-Vw, Nw), rough).rgb * (f0 * abk.x + abk.y) * vis * smoothstep(-0.1, 0.2, L.z);
  spec += PI * uRimColor * specSphere(Nl, V, Lr, rough, f0, 0.05) * ao * rimEye;
  spec += envSpecular(Nw, Vw, rough, f0) * uEnvSpec * pow(ao, 1.5) * headEnvOcc(vWPos, Nw, Vw);
  col += spec;
  col = min(col, vec3(64.0));
  if (any(isnan(col))) col = vec3(0.0);
  gl_FragColor = vec4(col, 1.0);
}`;

// ------------------------------------------------------------------ hair material
const HAIR_VS = /* glsl */`
attribute vec4 tangent4; attribute vec4 hattr;
uniform float uWidth; uniform float uTipWidth; uniform float uViewportH; uniform float uMinPix;
varying vec3 vWPos; varying vec3 vT; varying vec4 vH; varying float vCov;
void main() {
  vec3 wp = (modelMatrix * vec4(position, 1.0)).xyz;
  vec3 T = normalize(mat3(modelMatrix) * tangent4.xyz);
  bool ortho = projectionMatrix[3][3] > 0.5;
  vec3 V = ortho ? normalize(vec3(viewMatrix[0][2], viewMatrix[1][2], viewMatrix[2][2])) : normalize(cameraPosition - wp);
  vec3 side = cross(T, V);
  float sl = length(side);
  side = sl > 1e-4 ? side / sl : normalize(cross(T, vec3(0.0, 1.0, 0.0)));
  float t = hattr.x;
  float w = mix(uWidth, uTipWidth, t * t);
  vec4 clip = projectionMatrix * viewMatrix * vec4(wp, 1.0);
  float pix = ortho ? 2.0 / (projectionMatrix[1][1] * uViewportH) : clip.w * 2.0 / (projectionMatrix[1][1] * uViewportH);
  float wEff = max(w, pix * uMinPix);
  vCov = w / wEff;
  wp += side * (hattr.y * 2.0 - 1.0) * wEff * 0.5;
  vWPos = wp; vT = T; vH = hattr;
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}`;
const HAIR_FS = /* glsl */`
${GLSL_COMMON}
uniform vec3 uHairColor; uniform float uHairRough; uniform vec3 uHeadC; uniform float uSpecScale; uniform float uDiffScale;
varying vec3 vWPos; varying vec3 vT; varying vec4 vH; varying float vCov;
float hairG(float B, float th) { return exp(-0.5 * th * th / (B * B)) / (2.5066283 * B); }
float hairF(float c) { const float F0 = 0.04652; return F0 + (1.0 - F0) * pow(1.0 - c, 5.0); }
vec3 hairBSDF(vec3 T, vec3 V, vec3 L, vec3 base, float rough) {
  float sL = clamp(dot(T, L), -1.0, 1.0), sV = clamp(dot(T, V), -1.0, 1.0);
  float cosTD = cos(0.5 * abs(asin(sV) - asin(sL)));
  vec3 Lp = L - sL * T, Vp = V - sV * T;
  float cosPhi = dot(Lp, Vp) * inversesqrt(dot(Lp, Lp) * dot(Vp, Vp) + 1e-4);
  float cosHalfPhi = sqrt(clamp(0.5 + 0.5 * cosPhi, 0.0, 1.0));
  float n_p = 1.19 / cosTD + 0.36 * cosTD;
  float shift = 0.035;
  float r2 = rough * rough;
  float sa = sin(-2.0 * shift), ca = cos(-2.0 * shift);
  float shR = 2.0 * sa * (ca * cosHalfPhi * sqrt(max(1.0 - sV * sV, 0.0)) + sa * sV);
  vec3 S = vec3(hairG(r2, sL + sV - shR) * 0.25 * cosHalfPhi * min(hairF(sqrt(clamp(0.5 + 0.5 * dot(V, L), 0.0, 1.0))), 0.2)) * uSpecScale;
  float a = 1.0 / n_p;
  float h = cosHalfPhi * (1.0 + a * (0.6 - 0.8 * cosPhi));
  float f = hairF(cosTD * sqrt(clamp(1.0 - h * h, 0.0, 1.0)));
  vec3 Tp = pow(base, vec3(0.5 * sqrt(max(1.0 - h * h * a * a, 0.0)) / cosTD));
  S += hairG(r2 * 0.5, sL + sV - shift) * exp(-3.65 * cosPhi - 3.98) * (1.0 - f) * (1.0 - f) * Tp;
  f = hairF(cosTD * 0.5);
  Tp = pow(base, vec3(0.8 / cosTD));
  S += hairG(r2 * 2.0, sL + sV - 4.0 * shift) * exp(17.0 * cosPhi - 16.78) * (1.0 - f) * (1.0 - f) * f * Tp;
  return max(S, vec3(0.0));
}
vec3 hairDiffuse(vec3 T, vec3 V, vec3 L, vec3 base, float shadow) {
  float kd = 1.0 - abs(dot(T, L));
  vec3 fn = normalize(V - T * dot(V, T));
  float nl = clamp((dot(fn, L) + 1.0) / 4.0, 0.0, 1.0);
  float ds = (1.0 / PI) * mix(nl, kd, 0.33);
  float luma = dot(base, vec3(0.2126, 0.7152, 0.0722));
  vec3 tint = pow(base / max(luma, 1e-4), vec3(1.0 - shadow));
  return base * uDiffScale * ds * tint;
}
float hash13(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
void main() {
  float t = vH.x;
  float cov = vCov * (1.0 - smoothstep(0.9, 1.0, t));
  float rnd0 = hash13(vec3(gl_FragCoord.xy, uFrame * 7.31 + vH.z * 131.7));
#ifdef HAIR_DEPTH
  if (cov < 0.12) discard;
  gl_FragColor = vec4(gl_FragCoord.z, 0.0, 0.0, 1.0);
#else
  if (rnd0 > cov) discard;
  vec3 T = normalize(vT);
  vec3 V = normalize(cameraPosition - vWPos);
  vec3 L = normalize(uKeyDir);
  vec3 Lr = normalize(uRimDir);
  vec3 nOut = normalize(vWPos - uHeadC);
  float rnd = vH.z;
  float ao = vH.w;
  vec3 base = uHairColor * mix(0.75, 1.3, rnd);
  float rough = uHairRough * mix(0.9, 1.15, fract(rnd * 7.13));
  vec2 sh = keyShadowLite(vWPos, nOut);
  float vis = sh.x * sh.y;
  vec3 col = PI * uKeyColor * (hairBSDF(T, V, L, base, rough) + hairDiffuse(T, V, L, base, vis)) * vis;
  float rimVis = smoothstep(-0.15, 0.35, dot(nOut, Lr));
  col += PI * uRimColor * (hairBSDF(T, V, Lr, base, rough) + hairDiffuse(T, V, Lr, base, 1.0)) * mix(ao, 1.0, 0.5) * rimVis;
  col += shIrr(nOut) * uEnvDiff * base * uDiffScale * 0.6 * ao;
  vec3 Rn = normalize(V - T * dot(V, T));
  col += textureCubeUV(uEnv, reflect(-V, Rn), 0.35).rgb * 0.05 * ao * uEnvSpec;
  col = min(col, vec3(64.0));
  if (any(isnan(col))) col = vec3(0.0);
  gl_FragColor = vec4(col, 1.0);
#endif
}`;

// ------------------------------------------------------------------ procedural textures
function fsQuadRender(fs, size, type = THREE.UnsignedByteType, mip = true) {
  const rt = new THREE.WebGLRenderTarget(size, size, { type, generateMipmaps: mip, minFilter: mip ? THREE.LinearMipmapLinearFilter : THREE.LinearFilter, magFilter: THREE.LinearFilter, wrapS: THREE.RepeatWrapping, wrapT: THREE.RepeatWrapping, depthBuffer: false });
  const mat = new THREE.RawShaderMaterial({
    glslVersion: THREE.GLSL3,
    vertexShader: `in vec3 position; out vec2 vUv; void main(){ vUv = position.xy*0.5+0.5; gl_Position = vec4(position.xy,0.0,1.0); }`,
    fragmentShader: `precision highp float; in vec2 vUv; out vec4 outColor; ${fs}`,
  });
  const m = new THREE.Mesh(triGeo, mat); m.frustumCulled = false;
  const sc = new THREE.Scene(); sc.add(m);
  renderer.setRenderTarget(rt); renderer.render(sc, new THREE.OrthographicCamera()); renderer.setRenderTarget(null);
  mat.dispose();
  rt.texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return rt.texture;
}
const NOISE_GLSL = /* glsl */`
vec2 hash2(vec2 p) { p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3))); return fract(sin(p) * 43758.5453); }
float hash1(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec2 worley(vec2 uv, float n) {
  vec2 p = uv * n; vec2 ip = floor(p); vec2 fp = fract(p);
  float f1 = 8.0, f2 = 8.0;
  for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
    vec2 g = vec2(float(i), float(j)); vec2 cell = mod(ip + g, n); vec2 o = hash2(cell);
    vec2 r = g + o - fp; float d = dot(r, r);
    if (d < f1) { f2 = f1; f1 = d; } else if (d < f2) { f2 = d; }
  }
  return sqrt(vec2(f1, f2));
}
float vnoise(vec2 uv, float n) {
  vec2 p = uv * n; vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash1(mod(i, n)), b = hash1(mod(i + vec2(1, 0), n)), c = hash1(mod(i + vec2(0, 1), n)), d = hash1(mod(i + vec2(1, 1), n));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}`;
function makeDetailTexture(size) {
  return fsQuadRender(`${NOISE_GLSL}
  float height(vec2 uv, out float cav) {
    vec2 w = worley(uv, 72.0);
    float pr = hash1(floor(uv * 72.0) + 0.5);
    float pore = smoothstep(0.30, 0.02, w.x) * (0.55 + 0.9 * pr);
    vec2 w2 = worley(uv + 0.37, 26.0);
    float furrow = smoothstep(0.08, 0.0, w2.y - w2.x) * (0.5 + 0.5 * vnoise(uv, 40.0));
    vec2 w3 = worley(uv + 0.71, 9.0);
    float furrow2 = smoothstep(0.035, 0.0, w3.y - w3.x) * smoothstep(0.3, 0.8, vnoise(uv + 0.5, 12.0));
    float bump = vnoise(uv, 160.0) * 0.5 + vnoise(uv, 320.0) * 0.25 + vnoise(uv, 48.0) * 0.6;
    float und = vnoise(uv, 12.0) * 0.6 + vnoise(uv, 24.0) * 0.4;
    cav = 1.0 - 0.5 * pore - 0.2 * furrow - 0.15 * furrow2;
    return -pore - furrow * 0.35 - furrow2 * 0.25 + bump * 0.3 + und * 9.0;
  }
  void main() {
    float e = 1.0 / ${size}.0; float c, c2;
    float s = 0.55 * ${size}.0 / 1024.0;
    float h = height(vUv, c);
    float hx = height(vUv + vec2(e, 0.0), c2);
    float hy = height(vUv + vec2(0.0, e), c2);
    vec3 n = normalize(vec3((h - hx) * s, (h - hy) * s, 1.0));
    outColor = vec4(n.xy * 0.5 + 0.5, n.z, c);
  }`, size);
}
function makeIrisTexture() {
  const tex = fsQuadRender(`${NOISE_GLSL}
  void main() {
    vec2 p = vUv * 2.0 - 1.0; float r = length(p); float a = atan(p.y, p.x) / 6.2831853 + 0.5;
    float rp = 0.29;
    float t = clamp((r - rp) / (1.0 - rp), 0.0, 1.0);
    float fib = vnoise(vec2(a, r * 0.15), 180.0) * 0.6 + vnoise(vec2(a, r * 0.3), 90.0) * 0.4;
    float fib2 = vnoise(vec2(a, r * 0.5), 400.0);
    vec3 inner = vec3(0.075, 0.034, 0.011);
    vec3 mid = vec3(0.038, 0.018, 0.0075);
    vec3 outer = vec3(0.020, 0.010, 0.0055);
    vec3 col = mix(inner, mid, smoothstep(0.0, 0.45, t));
    col = mix(col, outer, smoothstep(0.45, 1.0, t));
    float coll = 0.30 + 0.05 * sin(a * 6.2831853 * 11.0 + vnoise(vec2(a, 0.0), 30.0) * 4.0);
    col *= 1.0 + 0.55 * smoothstep(0.06, 0.0, abs(t - coll));
    col *= 0.65 + 0.7 * fib;
    col *= 0.85 + 0.3 * fib2;
    float crypt = smoothstep(0.55, 0.85, vnoise(vec2(a, r), 26.0)) * smoothstep(0.25, 0.4, t) * smoothstep(0.85, 0.6, t);
    col *= 1.0 - 0.45 * crypt;
    col *= mix(1.0, 0.25, smoothstep(0.82, 1.0, t));
    col = mix(col, vec3(0.02, 0.012, 0.008), smoothstep(0.06, 0.0, t));
    outColor = vec4(col, 1.0);
  }`, 512, THREE.HalfFloatType, true);
  tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
  return tex;
}

// ------------------------------------------------------------------ shadows
const SHADOW_SIZE = (!isSmall && renderer.capabilities.maxTextureSize >= 4096) ? 4096 : 2048;
function makeShadowRT(size) {
  const rt = new THREE.WebGLRenderTarget(size, size, { type: FLOAT_RT ? THREE.FloatType : THREE.UnsignedByteType, format: FLOAT_RT ? THREE.RedFormat : THREE.RGBAFormat, depthBuffer: true, generateMipmaps: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
  rt.depthTexture = new THREE.DepthTexture(size, size, THREE.UnsignedIntType);
  rt.depthTexture.compareFunction = THREE.LessEqualCompare;
  rt.depthTexture.minFilter = THREE.LinearFilter; rt.depthTexture.magFilter = THREE.LinearFilter;
  return rt;
}
const shadowRT = makeShadowRT(SHADOW_SIZE);
const hairShadowRT = makeShadowRT(SHADOW_SIZE / 2);
const SHADOW_HALF = 0.17;
const shadowCam = new THREE.OrthographicCamera(-SHADOW_HALF, SHADOW_HALF, SHADOW_HALF, -SHADOW_HALF, 0.3, 1.3);
const depthMat = new THREE.ShaderMaterial({
  defines: FLOAT_RT ? {} : { SHADOW_PACKED: '' },
  vertexShader: 'void main(){ gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
  fragmentShader: '#include <packing>\nvoid main(){\n#ifdef SHADOW_PACKED\n gl_FragColor = packDepthToRGBA(gl_FragCoord.z);\n#else\n gl_FragColor = vec4(gl_FragCoord.z, 0.0, 0.0, 1.0);\n#endif\n}',
  side: THREE.DoubleSide,
});
U.uShadowRaw.value = shadowRT.texture;
U.uShadowCmp.value = shadowRT.depthTexture;
U.uHairShadow.value = hairShadowRT.texture;
function updateShadowCamera() {
  const L = U.uKeyDir.value;
  const c = new THREE.Vector3(0, 0.5, 0.03);
  shadowCam.position.copy(c).addScaledVector(L, 0.8);
  shadowCam.up.set(0, 1, 0);
  if (Math.abs(L.y) > 0.95) shadowCam.up.set(0, 0, 1);
  shadowCam.lookAt(c);
  shadowCam.updateMatrixWorld(); shadowCam.updateProjectionMatrix();
  const bias = new THREE.Matrix4().set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1);
  U.uShadowMat.value.copy(bias).multiply(shadowCam.projectionMatrix).multiply(shadowCam.matrixWorldInverse);
  U.uShadowRot.value.setFromMatrix4(shadowCam.matrixWorldInverse);
  const range = shadowCam.far - shadowCam.near, width = SHADOW_HALF * 2;
  U.uShadowP.value.set(1 / SHADOW_SIZE, range * 2 * U.uKeyTan.value / width, range, width / SHADOW_SIZE);
}

// ------------------------------------------------------------------ data decoding
function b64ToBytes(b64) {
  const bin = atob(b64); const n = bin.length; const out = new Uint8Array(n);
  for (let i = 0; i < n; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function gunzip(bytes) {
  if (typeof DecompressionStream !== 'undefined') {
    const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return new Uint8Array(await new Response(s).arrayBuffer());
  }
  const { gunzipSync } = await import('https://cdn.jsdelivr.net/npm/fflate@0.8.2/esm/browser.js');
  return gunzipSync(bytes);
}
function parseContainer(u8) {
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const hlen = dv.getUint32(4, true);
  const header = JSON.parse(new TextDecoder().decode(u8.subarray(8, 8 + hlen)));
  const base = 8 + hlen + ((4 - (hlen % 4)) % 4);
  const B = {};
  for (const b of header.buffers) {
    const src = u8.subarray(base + b.byteOffset, base + b.byteOffset + b.byteLength);
    if (b.enc === 'mv') { const out = new Uint8Array(b.count * b.stride); MeshoptDecoder.decodeVertexBuffer(out, b.count, b.stride, src); B[b.name] = { info: b, data: out }; }
    else if (b.enc === 'mi') { const out = new Uint32Array(b.count); MeshoptDecoder.decodeIndexBuffer(new Uint8Array(out.buffer), b.count, 4, src); B[b.name] = { info: b, data: out }; }
    else B[b.name] = { info: b, data: src };
  }
  return { meta: header.meta, B };
}

// ------------------------------------------------------------------ geometry builders
function buildHead(buf) {
  const { info, data } = buf;
  const n = info.count, st = info.stride, lo = info.lo, hi = info.hi;
  const pos = new Float32Array(n * 3), alb = new Uint8Array(n * 3), aA = new Uint8Array(n * 4), aB = new Uint8Array(n * 4), ns = new Float32Array(n * 3);
  const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  for (let i = 0; i < n; i++) {
    const o = i * st;
    for (let k = 0; k < 3; k++) pos[i * 3 + k] = lo[k] + dv.getUint16(o + k * 2, true) / 65535 * (hi[k] - lo[k]);
    alb[i * 3] = data[o + 6]; alb[i * 3 + 1] = data[o + 7]; alb[i * 3 + 2] = data[o + 8];
    aA[i * 4] = data[o + 9]; aA[i * 4 + 1] = data[o + 10]; aA[i * 4 + 2] = data[o + 11]; aA[i * 4 + 3] = data[o + 12];
    aB[i * 4] = data[o + 13]; aB[i * 4 + 1] = data[o + 14]; aB[i * 4 + 2] = data[o + 15]; aB[i * 4 + 3] = 0;
    let x = dv.getInt8(o + 16) / 127, y = dv.getInt8(o + 17) / 127;
    let z = 1 - Math.abs(x) - Math.abs(y);
    if (z < 0) { const ox = x, oy = y; x = (1 - Math.abs(oy)) * (ox >= 0 ? 1 : -1); y = (1 - Math.abs(ox)) * (oy >= 0 ? 1 : -1); }
    const l = Math.hypot(x, y, z) || 1;
    ns[i * 3] = x / l; ns[i * 3 + 1] = y / l; ns[i * 3 + 2] = z / l;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('albedo', new THREE.BufferAttribute(alb, 3, true));
  g.setAttribute('attrA', new THREE.BufferAttribute(aA, 4, true));
  g.setAttribute('attrB', new THREE.BufferAttribute(aB, 4, true));
  g.setAttribute('nsmooth', new THREE.BufferAttribute(ns, 3));
  return g;
}
function buildEye(e, meta, aoBytes) {
  const nlat = meta.eye_mesh.nlat, nlon = meta.eye_mesh.nlon;
  const Rs = meta.eyes.R, Rc = meta.eyes.Rc, zcc = meta.eyes.zcc;
  const R = e.rot, c = e.center;
  const nv = (nlat + 1) * (nlon + 1);
  const pos = new Float32Array(nv * 3), loc = new Float32Array(nv * 3), ao = new Float32Array(nv);
  let v = 0;
  for (let i = 0; i <= nlat; i++) {
    const th = Math.PI * Math.pow(i / nlat, 1.6);
    for (let j = 0; j <= nlon; j++, v++) {
      const ph = 2 * Math.PI * j / nlon;
      const dx = Math.sin(th) * Math.cos(ph), dy = Math.sin(th) * Math.sin(ph), dz = Math.cos(th);
      const b = dz * zcc, disc = b * b - (zcc * zcc - Rc * Rc);
      const tc = disc >= 0 ? b + Math.sqrt(disc) : 0;
      const k = 0.00025, hh = Math.min(1, Math.max(0, 0.5 + 0.5 * (tc - Rs) / k));
      const t = tc * hh + Rs * (1 - hh) + k * hh * (1 - hh);
      const px = dx * t, py = dy * t, pz = dz * t;
      loc[v * 3] = px; loc[v * 3 + 1] = py; loc[v * 3 + 2] = pz;
      pos[v * 3] = R[0][0] * px + R[0][1] * py + R[0][2] * pz + c[0];
      pos[v * 3 + 1] = R[1][0] * px + R[1][1] * py + R[1][2] * pz + c[1];
      pos[v * 3 + 2] = R[2][0] * px + R[2][1] * py + R[2][2] * pz + c[2];
      ao[v] = aoBytes[v] / 255;
    }
  }
  const idx = [];
  const id = (i, j) => i * (nlon + 1) + j;
  for (let i = 0; i < nlat; i++) for (let j = 0; j < nlon; j++) {
    const a = id(i, j), b = id(i + 1, j), cc = id(i + 1, j + 1), d = id(i, j + 1);
    idx.push(a, b, cc, a, cc, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('eyelocal', new THREE.BufferAttribute(loc, 3));
  g.setAttribute('eyeao', new THREE.BufferAttribute(ao, 1));
  g.setIndex(idx);
  g.computeBoundingSphere();
  return g;
}
function decodeStrands(B, name) {
  const r = B[name + '_r'], d = B[name + '_d'], n = B[name + '_n'];
  const nS = n.info.strands, lo = r.info.lo, hi = r.info.hi, dq = d.info.dq;
  const counts = n.data.subarray(0, nS);
  let total = 0; for (let i = 0; i < nS; i++) total += counts[i];
  const P = new Float32Array(total * 3);
  const rv = new DataView(r.data.buffer, r.data.byteOffset, r.data.byteLength);
  const dd = new Int8Array(d.data.buffer, d.data.byteOffset, d.data.byteLength);
  let p = 0, q = 0;
  for (let i = 0; i < nS; i++) {
    let x = lo[0] + rv.getUint16(i * 6, true) / 65535 * (hi[0] - lo[0]);
    let y = lo[1] + rv.getUint16(i * 6 + 2, true) / 65535 * (hi[1] - lo[1]);
    let z = lo[2] + rv.getUint16(i * 6 + 4, true) / 65535 * (hi[2] - lo[2]);
    P[p++] = x; P[p++] = y; P[p++] = z;
    for (let j = 1; j < counts[i]; j++) {
      x += dd[q++] * dq; y += dd[q++] * dq; z += dd[q++] * dq;
      P[p++] = x; P[p++] = y; P[p++] = z;
    }
  }
  return { P, counts, nS, total };
}
// density-based self occlusion for hair points (how much hair lies outward of a point)
function hairOcclusion(P, total, center, k = 0.1) {
  let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  for (let i = 0; i < total; i++) for (let a = 0; a < 3; a++) { const v = P[i * 3 + a]; if (v < mn[a]) mn[a] = v; if (v > mx[a]) mx[a] = v; }
  const h = 0.0015; mn = mn.map(v => v - 0.01);
  const dims = mx.map((v, a) => Math.ceil((v + 0.01 - mn[a]) / h) + 1);
  const [dx, dy, dz] = dims;
  let grid = new Float32Array(dx * dy * dz);
  for (let i = 0; i < total; i++) {
    const gx = Math.floor((P[i * 3] - mn[0]) / h), gy = Math.floor((P[i * 3 + 1] - mn[1]) / h), gz = Math.floor((P[i * 3 + 2] - mn[2]) / h);
    grid[(gx * dy + gy) * dz + gz] += 1;
  }
  // separable [1,2,1]/4 blur x2 (approx gaussian)
  const tmp = new Float32Array(grid.length);
  const blur = (src, dst, stride, len, outer) => {
    for (let o = 0; o < src.length; o++) {
      const c = Math.floor(o / stride) % len;
      const a = c > 0 ? src[o - stride] : 0, b = c < len - 1 ? src[o + stride] : 0;
      dst[o] = 0.25 * a + 0.5 * src[o] + 0.25 * b;
    }
  };
  for (let pass = 0; pass < 2; pass++) { blur(grid, tmp, dy * dz, dx); blur(tmp, grid, dz, dy); blur(grid, tmp, 1, dz); grid.set(tmp); }
  const ao = new Float32Array(total);
  for (let i = 0; i < total; i++) {
    let x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2];
    let vx = x - center[0], vy = y - center[1], vz = z - center[2];
    const l = Math.hypot(vx, vy, vz) || 1; vx /= l; vy /= l; vz /= l;
    let acc = 0;
    for (let s = 1; s < 14; s++) {
      const gx = Math.floor((x + vx * s * h - mn[0]) / h), gy = Math.floor((y + vy * s * h - mn[1]) / h), gz = Math.floor((z + vz * s * h - mn[2]) / h);
      if (gx < 0 || gy < 0 || gz < 0 || gx >= dx || gy >= dy || gz >= dz) continue;
      acc += grid[(gx * dy + gy) * dz + gz];
    }
    ao[i] = Math.exp(-k * acc);
  }
  return ao;
}
// lighter hair for phones: keep every k-th strand (the caller widens the strands to keep the same coverage)
function subsetStrands(S, ao, k) {
  const { P, counts, nS } = S;
  const starts = new Uint32Array(nS); let p = 0;
  for (let i = 0; i < nS; i++) { starts[i] = p; p += counts[i]; }
  let n = 0, total = 0;
  for (let i = 0; i < nS; i += k) { n++; total += counts[i]; }
  const P2 = new Float32Array(total * 3), ao2 = new Float32Array(total), c2 = new Uint8Array(n);
  let q = 0, j = 0;
  for (let i = 0; i < nS; i += k, j++) {
    const c = counts[i]; c2[j] = c;
    P2.set(P.subarray(starts[i] * 3, (starts[i] + c) * 3), q * 3);
    ao2.set(ao.subarray(starts[i], starts[i] + c), q);
    q += c;
  }
  return { S: { P: P2, counts: c2, nS: n, total }, ao: ao2 };
}
function buildRibbons(S, ao, seed) {
  const { P, counts, nS, total } = S;
  const nv = total * 2;
  const pos = new Float32Array(nv * 3), tan = new Int8Array(nv * 4), ha = new Uint8Array(nv * 4);
  let segs = 0; for (let i = 0; i < nS; i++) segs += counts[i] - 1;
  const idx = new Uint32Array(segs * 6);
  let p = 0, v = 0, ii = 0; let rs = seed >>> 0;
  const rand = () => { rs = (rs * 1664525 + 1013904223) >>> 0; return rs / 4294967296; };
  for (let i = 0; i < nS; i++) {
    const n = counts[i], r = Math.floor(rand() * 255);
    for (let j = 0; j < n; j++) {
      const a = p + Math.max(j - 1, 0), b = p + Math.min(j + 1, n - 1);
      let tx = P[b * 3] - P[a * 3], ty = P[b * 3 + 1] - P[a * 3 + 1], tz = P[b * 3 + 2] - P[a * 3 + 2];
      const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
      const t = Math.round(j / (n - 1) * 255), o = Math.round((ao ? ao[p + j] : 0.8) * 255);
      for (let s = 0; s < 2; s++, v++) {
        pos[v * 3] = P[(p + j) * 3]; pos[v * 3 + 1] = P[(p + j) * 3 + 1]; pos[v * 3 + 2] = P[(p + j) * 3 + 2];
        tan[v * 4] = Math.round(tx * 127); tan[v * 4 + 1] = Math.round(ty * 127); tan[v * 4 + 2] = Math.round(tz * 127);
        ha[v * 4] = t; ha[v * 4 + 1] = s * 255; ha[v * 4 + 2] = r; ha[v * 4 + 3] = o;
      }
      if (j < n - 1) {
        const b0 = (p + j) * 2;
        idx[ii++] = b0; idx[ii++] = b0 + 1; idx[ii++] = b0 + 2; idx[ii++] = b0 + 1; idx[ii++] = b0 + 3; idx[ii++] = b0 + 2;
      }
    }
    p += n;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('tangent4', new THREE.BufferAttribute(tan, 4, true));
  g.setAttribute('hattr', new THREE.BufferAttribute(ha, 4, true));
  g.setIndex(new THREE.BufferAttribute(idx, 1));
  g.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0.52, 0.03), 0.2);
  return g;
}

// ------------------------------------------------------------------ scene assembly
const opaque = []; const hairObjs = [];
let shadowsDirty = true;
let currentPreset = 'studio';
function applyPreset(name) {
  const p = PRESETS[name]; currentPreset = name;
  const env = buildEnvironment(p);
  if (U.uEnv.value) U.uEnv.value.dispose();
  U.uEnv.value = env.pmrem;
  const envk = buildEnvironment(p, true);
  if (U.uEnvKey.value) U.uEnvKey.value.dispose();
  U.uEnvKey.value = envk.pmrem;
  env.sh.forEach((v, i) => U.uSH.value[i].copy(v));
  U.uKeyDir.value.copy(dirAE(p.key.az, p.key.el));
  U.uKeyColor.value.set(...p.key.c);
  U.uKeyTan.value = Math.tan(p.key.size * DEG);
  U.uRimDir.value.copy(dirAE(p.rim.az, p.rim.el));
  U.uRimColor.value.set(...p.rim.c);
  BG.uBgA.value.set(...p.bg[0]); BG.uBgB.value.set(...p.bg[1]);
  renderer.toneMappingExposure = qs.get('exp') ? parseFloat(qs.get('exp')) : p.exposure;
  updateShadowCamera();
  shadowsDirty = true; resetAccum();
}

function makeHairMesh(geo, p, defines) {
  const hu = Object.assign({}, U, {
    uWidth: { value: p.width }, uTipWidth: { value: p.width * p.tip }, uViewportH: { value: innerHeight * PR }, uMinPix: { value: p.minPix ?? 0.7 },
    uHairColor: { value: new THREE.Vector3(...p.color) }, uHairRough: { value: p.rough }, uSpecScale: { value: p.spec ?? 1.0 }, uDiffScale: { value: p.diff ?? 1.3 },
    uHeadC: { value: new THREE.Vector3(...(p.center || [0, 0.515, 0.035])) },
  });
  const m = new THREE.ShaderMaterial({ uniforms: hu, vertexShader: HAIR_VS, fragmentShader: HAIR_FS, defines, side: THREE.DoubleSide });
  const dm = new THREE.ShaderMaterial({ uniforms: Object.assign({}, hu, { uViewportH: { value: SHADOW_SIZE / 2 }, uMinPix: { value: 1.2 } }), vertexShader: HAIR_VS, fragmentShader: HAIR_FS, defines: Object.assign({ HAIR_DEPTH: '' }, defines), side: THREE.DoubleSide });
  const mesh = new THREE.Mesh(geo, m);
  mesh.frustumCulled = false; mesh.userData.depthMat = dm; mesh.userData.hu = hu;
  scene.add(mesh); hairObjs.push(mesh);
  return mesh;
}

let MeshoptDecoder = null;
async function init() {
  setProgress(0.04, 'Decoding model');
  MeshoptDecoder = window.MeshoptDecoderRef;
  const b64 = window.MODEL_B64 || await (await fetch('var/model.b64')).text();
  await nextFrame();
  const raw = await gunzip(b64ToBytes(b64));
  setProgress(0.18, 'Unpacking geometry');
  await nextFrame();
  const { meta, B } = parseContainer(raw);
  setProgress(0.32, 'Building skin');
  await nextFrame();
  // textures
  const lutInfo = meta.lut;
  const lut = new THREE.DataTexture(B.lut.data.slice(0, lutInfo.w * lutInfo.h * 4), lutInfo.w, lutInfo.h, THREE.RGBAFormat, THREE.UnsignedByteType);
  lut.colorSpace = THREE.NoColorSpace; lut.minFilter = THREE.LinearFilter; lut.magFilter = THREE.LinearFilter; lut.generateMipmaps = false;
  lut.wrapS = lut.wrapT = THREE.ClampToEdgeWrapping; lut.needsUpdate = true;
  U.uLUT.value = lut;
  U.uDetail.value = makeDetailTexture(isSmall ? 512 : 1024);
  const irisTex = makeIrisTexture();
  applyPreset(currentPreset);
  ENV_DEFINES = envDefines(U.uEnv.value);
  // head
  const hg = buildHead(B.head_v);
  hg.setIndex(new THREE.BufferAttribute(B.head_i.data, 1));
  hg.computeVertexNormals();
  hg.computeBoundingSphere();
  const skinMat = new THREE.ShaderMaterial({ uniforms: U, vertexShader: SKIN_VS, fragmentShader: SKIN_FS, defines: ENV_DEFINES });
  const head = new THREE.Mesh(hg, skinMat);
  scene.add(head); opaque.push(head);
  // eyes
  for (const s of ['l', 'r']) {
    const e = meta.eyes.eyes[s];
    const eu = Object.assign({}, U, {
      uEyeRot: { value: new THREE.Matrix3().set(...e.rot.flat()) },
      uZcc: { value: meta.eyes.zcc }, uRL: { value: meta.eyes.RL }, uIrisZ: { value: meta.eyes.zL - 0.0004 }, uPupil: { value: 0.0017 },
      uIris: { value: irisTex },
    });
    const em = new THREE.ShaderMaterial({ uniforms: eu, vertexShader: EYE_VS, fragmentShader: EYE_FS, defines: ENV_DEFINES });
    const eye = new THREE.Mesh(buildEye(e, meta, B['eye_ao_' + s].data), em);
    scene.add(eye); opaque.push(eye);
  }
  setProgress(0.5, 'Growing hair');
  await nextFrame();
  const center = [0, 0.515, 0.035];
  const hairS = decodeStrands(B, 'hair');
  const hairAO = hairOcclusion(hairS.P, hairS.total, center);
  setProgress(0.75, 'Placing strands');
  await nextFrame();
  const lite = isSmall ? subsetStrands(hairS, hairAO, 2) : { S: hairS, ao: hairAO };
  window.__hair = makeHairMesh(buildRibbons(lite.S, lite.ao, 17), { width: isSmall ? 0.00017 : 0.00012, tip: 0.45, color: [0.020, 0.0125, 0.0082], rough: 0.38, diff: 1.3, spec: 0.38 }, ENV_DEFINES);
  const brows = decodeStrands(B, 'brows');
  makeHairMesh(buildRibbons(brows, null, 5), { width: 0.00010, tip: 0.3, color: [0.016, 0.009, 0.006], rough: 0.62, spec: 0.15, diff: 1.3, center: [0, 0.515, 0.06] }, ENV_DEFINES);
  const lashes = decodeStrands(B, 'lashes');
  makeHairMesh(buildRibbons(lashes, null, 9), { width: 0.00012, tip: 0.25, color: [0.006, 0.004, 0.003], rough: 0.55, spec: 0.3, diff: 1.3, center: [0, 0.51, 0.10] }, ENV_DEFINES);
  setProgress(0.95, 'Compiling shaders');
  await nextFrame();
  renderer.compile(scene, camera);
  setProgress(1, '');
  document.body.classList.add('ready');
  window.__ready = true;
  if (!SHOT) animate();
}
function nextFrame() { return new Promise(r => requestAnimationFrame(() => r())); }

function renderShadows() {
  bgMesh.visible = false;
  const saved = opaque.map(o => o.material);
  opaque.forEach(o => o.material = depthMat);
  const hv = hairObjs.map(o => o.visible);
  hairObjs.forEach(o => o.visible = false);
  renderer.setClearColor(0xffffff, 1);
  renderer.setRenderTarget(shadowRT); renderer.clear(); renderer.render(scene, shadowCam);
  opaque.forEach((o, i) => { o.material = saved[i]; o.visible = false; });
  hairObjs.forEach((o, i) => { o.visible = hv[i]; o.userData.mainMat = o.material; o.material = o.userData.depthMat; });
  renderer.setRenderTarget(hairShadowRT); renderer.clear(); renderer.render(scene, shadowCam);
  hairObjs.forEach(o => { o.material = o.userData.mainMat; });
  opaque.forEach(o => o.visible = true);
  renderer.setRenderTarget(null);
  renderer.setClearColor(0x000000, 1);
  bgMesh.visible = true;
  shadowsDirty = false;
}

// ------------------------------------------------------------------ progressive accumulation
let accCount = 0;
const MAX_ACC = SHOT ? parseInt(qs.get('acc') || '16') : (isSmall ? 20 : 40);
const rtOpts = { type: THREE.HalfFloatType, depthBuffer: true, generateMipmaps: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter };
let sceneRT, accRT = [];
function allocRTs() {
  const w = Math.max(1, Math.floor(innerWidth * PR)), h = Math.max(1, Math.floor(innerHeight * PR));
  if (sceneRT) { sceneRT.dispose(); accRT.forEach(r => r.dispose()); }
  sceneRT = new THREE.WebGLRenderTarget(w, h, Object.assign({ samples: 4 }, rtOpts));
  accRT = [0, 1].map(() => new THREE.WebGLRenderTarget(w, h, Object.assign({}, rtOpts, { depthBuffer: false })));
  BG.uRes.value.set(w, h);
  for (const o of hairObjs) o.userData.hu.uViewportH.value = h;
}
allocRTs();
const quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const accMat = new THREE.ShaderMaterial({
  uniforms: { tNew: { value: null }, tAcc: { value: null }, uW: { value: 1 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = position.xy*0.5+0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: 'uniform sampler2D tNew; uniform sampler2D tAcc; uniform float uW; varying vec2 vUv; void main(){ gl_FragColor = mix(texture2D(tAcc, vUv), texture2D(tNew, vUv), uW); }',
  depthTest: false, depthWrite: false, toneMapped: false, blending: THREE.NoBlending,
});
const dispMat = new THREE.ShaderMaterial({
  uniforms: { tAcc: { value: null }, uSeed: { value: 0 }, uSat: { value: parseFloat(qs.get('sat') || '1.15') }, uContrast: { value: parseFloat(qs.get('con') || '1.05') }, uVignette: { value: 0.22 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = position.xy*0.5+0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }',
  fragmentShader: `uniform sampler2D tAcc; uniform float uSeed; uniform float uSat; uniform float uContrast; uniform float uVignette; varying vec2 vUv;
    float h12(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + uSeed) * 43758.5453); }
    void main(){
      vec3 rgb = texture2D(tAcc, vUv).rgb;
      vec2 q = vUv - 0.5; rgb *= 1.0 - uVignette * dot(q, q) * 1.6;
      rgb = toneMapping(rgb);
      float lum = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
      rgb = max(mix(vec3(lum), rgb, uSat), 0.0);
      rgb = sRGBTransferOETF(vec4(rgb, 1.0)).rgb;
      rgb = clamp((rgb - 0.5) * uContrast + 0.5, 0.0, 1.0);
      rgb += (h12(gl_FragCoord.xy) - 0.5) / 255.0;
      gl_FragColor = vec4(rgb, 1.0);
    }`,
  depthTest: false, depthWrite: false, toneMapped: true, blending: THREE.NoBlending,
});
const quadMesh = new THREE.Mesh(triGeo, accMat); quadMesh.frustumCulled = false;
const quadScene = new THREE.Scene(); quadScene.add(quadMesh);
function halton(i, b) { let f = 1, r = 0; while (i > 0) { f /= b; r += f * (i % b); i = Math.floor(i / b); } return r; }
function renderPass() {
  if (shadowsDirty) renderShadows();
  const w = sceneRT.width, h = sceneRT.height;
  const jx = accCount === 0 ? 0 : halton(accCount, 2) - 0.5;
  const jy = accCount === 0 ? 0 : halton(accCount, 3) - 0.5;
  camera.setViewOffset(w, h, jx, jy, w, h);
  U.uFrame.value = accCount;
  renderer.setRenderTarget(sceneRT); renderer.clear(); renderer.render(scene, camera);
  camera.clearViewOffset();
  const src = accRT[0], dst = accRT[1];
  accMat.uniforms.tNew.value = sceneRT.texture; accMat.uniforms.tAcc.value = src.texture; accMat.uniforms.uW.value = 1 / (accCount + 1);
  quadMesh.material = accMat;
  renderer.setRenderTarget(dst); renderer.render(quadScene, quadCam);
  accRT = [dst, src];
  dispMat.uniforms.tAcc.value = dst.texture; dispMat.uniforms.uSeed.value = (accCount * 0.618) % 1;
  quadMesh.material = dispMat;
  renderer.setRenderTarget(null); renderer.render(quadScene, quadCam);
  accCount++;
  updateStatus();
}
function resetAccum() { accCount = 0; }
controls.addEventListener('change', resetAccum);
controls.addEventListener('start', () => { document.body.classList.add('interacted'); });
function animate() {
  requestAnimationFrame(animate);
  const moved = controls.update();
  if (controls.autoRotate) resetAccum();
  if (accCount < MAX_ACC) renderPass();
}
window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight, false); allocRTs(); resetAccum();
});

// ------------------------------------------------------------------ UI wiring
function setProgress(f, label) {
  const bar = $('loadbar'); if (bar) bar.style.transform = `scaleX(${f})`;
  const l = $('loadlabel'); if (l && label) l.textContent = label;
}
function showError(msg) {
  const l = $('loadlabel'); if (l) l.textContent = msg;
  document.body.classList.add('failed');
}
let lastStatus = '';
function updateStatus() {
  const el = $('status'); if (!el) return;
  const txt = controls.autoRotate ? 'Turntable' : accCount >= MAX_ACC ? 'Refined' : `Refining ${Math.round(accCount / MAX_ACC * 100)}%`;
  if (txt !== lastStatus) { el.textContent = txt; lastStatus = txt; el.dataset.done = accCount >= MAX_ACC ? '1' : '0'; }
}
function wireUI() {
  document.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('[data-preset]').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    applyPreset(b.dataset.preset);
  }));
  const hairBtn = $('toggle-hair');
  hairBtn?.addEventListener('click', () => {
    const on = hairBtn.getAttribute('aria-pressed') !== 'true';
    hairBtn.setAttribute('aria-pressed', String(on));
    if (window.__hair) window.__hair.visible = on;
    shadowsDirty = true; resetAccum();
  });
  const turn = $('toggle-turn');
  turn?.addEventListener('click', () => {
    const on = turn.getAttribute('aria-pressed') !== 'true';
    turn.setAttribute('aria-pressed', String(on));
    controls.autoRotate = on; resetAccum();
  });
  $('reset')?.addEventListener('click', () => { placeCamera(HOME.yaw, HOME.pitch, HOME.dist); resetAccum(); });
  canvas.addEventListener('dblclick', () => { placeCamera(HOME.yaw, HOME.pitch, HOME.dist); resetAccum(); });
}
wireUI();

// test hook
window.setView = (yaw = 25, pitch = 3, dist = 0.8, ty = TARGET.y, tz = TARGET.z, fov = 24, tx = 0) => {
  camera.fov = fov; camera.updateProjectionMatrix();
  placeCamera(yaw, pitch, dist, tx, ty, tz);
  resetAccum();
  while (accCount < MAX_ACC) renderPass();
  return true;
};
window.setPreset = (n) => { applyPreset(n); return true; };
init().catch(e => { console.error(e); showError('The model could not be loaded: ' + e.message); });
