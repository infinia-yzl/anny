import sys, json
shell = open('/home/claude/web/shell.html').read()
importmap = '<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.186.0/build/three.module.js","three/addons/":"https://cdn.jsdelivr.net/npm/three@0.186.0/examples/jsm/"}}</script>'
mode = sys.argv[1] if len(sys.argv) > 1 else 'dev'
if mode == 'dev':
    page = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">' + \
        shell + '<script src="meshopt_ref.js"></script>' + importmap + '<script type="module" src="app.js"></script></head><body></body></html>'
    open('/home/claude/web/index_dev.html', 'w').write(page)
else:
    ref = open('/home/claude/web/meshopt_ref.js').read()
    app = open('/home/claude/web/app.js').read()
    b64 = open('/home/claude/web/var/model.b64').read().strip()
    data_script = '<script>window.MODEL_B64 = "' + b64 + '";</script>'
    page = shell + '\n<script>\n' + ref + '\n</script>\n' + importmap + '\n<script type="module">\n' + app + '\n</script>\n' + data_script + '\n'
    out = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/web/final.html'
    open(out, 'w').write(page)
    print('final page bytes', len(page))
