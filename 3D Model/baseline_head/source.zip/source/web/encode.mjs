import { MeshoptEncoder } from 'meshoptimizer';
import fs from 'fs';
import zlib from 'zlib';
await MeshoptEncoder.ready;
const dir = '/home/claude/pack';
const man = JSON.parse(fs.readFileSync(dir + '/manifest.json'));
const parts = []; const header = { buffers: [], meta: { eyes: man.eyes, eye_mesh: man.eye_mesh, lut: man.lut } };
let offset = 0;
function push(entry, bytes) {
  const pad = (4 - (bytes.length % 4)) % 4;
  entry.byteOffset = offset; entry.byteLength = bytes.length;
  parts.push(Buffer.from(bytes)); if (pad) parts.push(Buffer.alloc(pad));
  offset += bytes.length + pad;
  header.buffers.push(entry);
}
const bufs = Object.fromEntries(man.buffers.map(b => [b.name, b]));
// head: reorder for cache efficiency
{
  const hv = bufs['head_v'], hi = bufs['head_i'];
  const vdata = new Uint8Array(fs.readFileSync(dir + '/head_v.raw'));
  const idx = new Uint32Array(new Uint8Array(fs.readFileSync(dir + '/head_i.raw')).buffer);
  const [remap, unique] = MeshoptEncoder.reorderMesh(idx, true, false);
  const nv = new Uint8Array(unique * hv.stride);
  for (let i = 0; i < hv.count; i++) { const r = remap[i]; if (r !== 0xffffffff) nv.set(vdata.subarray(i * hv.stride, (i + 1) * hv.stride), r * hv.stride); }
  const ev = MeshoptEncoder.encodeVertexBufferLevel(nv, unique, hv.stride, 3, 1);
  push({ name: 'head_v', enc: 'mv', count: unique, stride: hv.stride, lo: hv.lo, hi: hv.hi }, ev);
  header.meta.head_count = unique;
  const ei = MeshoptEncoder.encodeIndexBuffer(new Uint8Array(idx.buffer), idx.length, 4);
  push({ name: 'head_i', enc: 'mi', count: idx.length, stride: 4 }, ei);
  console.log('head', unique, 'verts; vb', ev.length, 'ib', ei.length);
}
for (const b of man.buffers) {
  if (b.name.startsWith('head_')) continue;
  const data = new Uint8Array(fs.readFileSync(dir + '/' + b.name + '.raw'));
  if (b.kind === 'vertex') {
    const e = MeshoptEncoder.encodeVertexBufferLevel(data, b.count, b.stride, 3, 1);
    push(Object.assign({ enc: 'mv' }, b), e);
    console.log(b.name, data.length, '->', e.length);
  } else {
    push(Object.assign({ enc: 'raw' }, b), data);
  }
}
const hjson = Buffer.from(JSON.stringify(header));
const hl = Buffer.alloc(8); hl.write('HDB1', 0); hl.writeUInt32LE(hjson.length, 4);
const hpad = (4 - (hjson.length % 4)) % 4;
const blob = Buffer.concat([hl, hjson, Buffer.alloc(hpad), ...parts]);
const gz = zlib.gzipSync(blob, { level: 9 });
fs.writeFileSync('/home/claude/web/var/model.bin.gz', gz);
fs.writeFileSync('/home/claude/web/var/model.b64', gz.toString('base64'));
console.log('blob', blob.length, 'gz', gz.length, 'b64', Math.ceil(gz.length / 3) * 4);
