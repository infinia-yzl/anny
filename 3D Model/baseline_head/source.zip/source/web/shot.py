import asyncio, sys, json, os, time
from playwright.async_api import async_playwright
import http.server, threading, functools
ROOT = '/home/claude/web'
NM = ROOT + '/node_modules/three/'
def serve():
    h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
    class Q(http.server.SimpleHTTPRequestHandler):
        def __init__(s, *a, **k): super().__init__(*a, directory=ROOT, **k)
        def log_message(s, *a): pass
    httpd = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Q)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd.server_address[1]
async def route_cdn(route):
    url = route.request.url
    pre = 'https://cdn.jsdelivr.net/npm/three@0.186.0/'
    if url.startswith(pre):
        p = NM + url[len(pre):].split('?')[0]
        if os.path.exists(p):
            await route.fulfill(path=p, headers={'content-type': 'application/javascript', 'access-control-allow-origin': '*'}); return
    await route.abort()
async def main(page_name, out, views, w=900, h=1000, query=''):
    port = serve()
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        pg = await b.new_page(viewport={'width': w, 'height': h})
        logs = []
        pg.on('console', lambda m: logs.append(m.type + ': ' + m.text))
        pg.on('pageerror', lambda e: logs.append('PAGEERROR: ' + str(e)))
        await pg.route('https://cdn.jsdelivr.net/**', route_cdn)
        t = time.time()
        await pg.goto(f'http://127.0.0.1:{port}/{page_name}{query}')
        try:
            await pg.wait_for_function('window.__ready === true', timeout=300000)
        except Exception as e:
            print('TIMEOUT waiting ready', e)
        print('ready in %.1fs' % (time.time() - t))
        for i, v in enumerate(views):
            await pg.evaluate(f'window.setView(...{json.dumps(v)})')
            await pg.wait_for_timeout(100)
            fn = f'{out}_{i}.png'
            await pg.screenshot(path=fn, timeout=600000)
            print('saved', fn)
        for l in logs[-30:]: print(l)
        await b.close()
if __name__ == '__main__':
    page_name = sys.argv[1]; out = sys.argv[2]; views = json.loads(sys.argv[3])
    w = int(sys.argv[4]) if len(sys.argv) > 4 else 900
    h = int(sys.argv[5]) if len(sys.argv) > 5 else 1000
    q = sys.argv[6] if len(sys.argv) > 6 else ''
    asyncio.run(main(page_name, out, views, w, h, q))
