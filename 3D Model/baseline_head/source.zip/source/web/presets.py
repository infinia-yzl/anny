import asyncio, sys, json
from playwright.async_api import async_playwright
from PIL import Image, ImageDraw
sys.path.insert(0, '/home/claude/web')
from shot import serve, route_cdn
async def run(page, names, view, out, w, h, query):
    port = serve()
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        pg = await b.new_page(viewport={'width': w, 'height': h})
        logs = []
        pg.on('console', lambda m: logs.append(m.type + ': ' + m.text))
        pg.on('pageerror', lambda e: logs.append('PAGEERROR: ' + str(e)))
        await pg.route('https://cdn.jsdelivr.net/**', route_cdn)
        await pg.goto(f'http://127.0.0.1:{port}/{page}?shot&{query}')
        await pg.wait_for_function('window.__ready === true', timeout=300000)
        ims = []
        for n in names:
            await pg.evaluate(f'window.setPreset({json.dumps(n)})')
            await pg.evaluate(f'window.setView(...{json.dumps(view)})')
            await pg.screenshot(path='/tmp/_p.png', timeout=600000)
            im = Image.open('/tmp/_p.png').convert('RGB'); ImageDraw.Draw(im).text((6, 6), n, fill=(255, 255, 0)); ims.append(im)
        for l in logs:
            if ('error' in l.lower() or 'warn' in l.lower()) and 'fonts' not in l: print(l)
        await b.close()
    cols = min(len(ims), 4); rows = (len(ims) + cols - 1) // cols
    o = Image.new('RGB', (w * cols, h * rows))
    for i, im in enumerate(ims): o.paste(im, ((i % cols) * w, (i // cols) * h))
    o.save(out)
if __name__ == '__main__':
    asyncio.run(run(sys.argv[1], json.loads(sys.argv[2]), json.loads(sys.argv[3]), sys.argv[4], int(sys.argv[5]), int(sys.argv[6]), sys.argv[7] if len(sys.argv) > 7 else 'acc=10'))
