import { MeshoptEncoder } from 'meshoptimizer';
import fs from 'fs';
import zlib from 'zlib';
await MeshoptEncoder.ready;
const dir = '/home/claude/pack';
const man = JSON.parse(fs.readFileSync(dir + '/manifest.json'));
const parts = []; const header = { buffers: [], meta: { eyes: man.eyes, eye_mesh: man.eye_mesh, lut: man.lut, skin: man.skin, wearables: man.wearables, morphs: man.morphs, rig: man.rig, motion: man.motion, correctives: man.correctives } };
let offset = 0;
function push(entry, bytes) {
  const pad = (4 - (bytes.length % 4)) % 4;
  entry.byteOffset = offset; entry.byteLength = bytes.length;
  parts.push(Buffer.from(bytes)); if (pad) parts.push(Buffer.alloc(pad));
  offset += bytes.length + pad;
  header.buffers.push(entry);
}
const bufs = Object.fromEntries(man.buffers.map(b => [b.name, b]));
const REMAP = {};
const COMPANIONS = ['_morph', '_bind', '_skin'];
// meshes: every '<name>_v' with a matching '<name>_i' is reordered for cache efficiency and index-encoded
function encodeMesh(prefix) {
  const hv = bufs[prefix + '_v'], hi = bufs[prefix + '_i'];
  const vdata = new Uint8Array(fs.readFileSync(dir + '/' + prefix + '_v.raw'));
  const idx = new Uint32Array(new Uint8Array(fs.readFileSync(dir + '/' + prefix + '_i.raw')).buffer);
  const [remap, unique] = MeshoptEncoder.reorderMesh(idx, true, false);
  // vertices that corrective shapes move come first, so the viewer uploads one short range per frame
  const hotBufs = man.buffers.filter(b => b.kind === 'sparse' && b.body === prefix);
  if (hotBufs.length) {
    const hot = new Uint8Array(unique);
    for (const b of hotBufs) {
      const data = new Uint8Array(fs.readFileSync(dir + '/' + b.name + '.raw'));
      const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
      for (let i = 0; i < b.count; i++) for (let f = 0; f < (b.fields || 1); f++) {
        const r = remap[dv.getUint32(i * b.stride + f * 4, true)];
        if (r !== 0xffffffff) hot[r] = 1;
      }
    }
    const perm = new Uint32Array(unique);
    let k = 0;
    for (let i = 0; i < unique; i++) if (hot[i]) perm[i] = k++;
    const nHot = k;
    for (let i = 0; i < unique; i++) if (!hot[i]) perm[i] = k++;
    for (let i = 0; i < remap.length; i++) if (remap[i] !== 0xffffffff) remap[i] = perm[remap[i]];
    for (let i = 0; i < idx.length; i++) idx[i] = perm[idx[i]];
    header.meta[prefix + '_hot'] = nHot;
    console.log(prefix, 'vertices moved by corrective shapes first:', nHot);
  }
  const nv = new Uint8Array(unique * hv.stride);
  for (let i = 0; i < hv.count; i++) { const r = remap[i]; if (r !== 0xffffffff) nv.set(vdata.subarray(i * hv.stride, (i + 1) * hv.stride), r * hv.stride); }
  const ev = MeshoptEncoder.encodeVertexBufferLevel(nv, unique, hv.stride, 3, 1);
  push({ name: prefix + '_v', enc: 'mv', count: unique, stride: hv.stride, lo: hv.lo, hi: hv.hi }, ev);
  header.meta[prefix + '_count'] = unique;
  const ei = MeshoptEncoder.encodeIndexBuffer(new Uint8Array(idx.buffer), idx.length, 4);
  push({ name: prefix + '_i', enc: 'mi', count: idx.length, stride: 4 }, ei);
  REMAP[prefix] = remap;
  // per-vertex companion streams follow the same vertex order: morph deltas ('_morph') and the binding of a
  // wearable to body vertices ('_bind', whose body indices follow the body's new vertex order as well)
  for (const suffix of COMPANIONS) {
    const mb = bufs[prefix + suffix];
    if (!mb) continue;
    const md = new Uint8Array(fs.readFileSync(dir + '/' + prefix + suffix + '.raw'));
    const nm = new Uint8Array(unique * mb.stride);
    for (let i = 0; i < mb.count; i++) { const r = remap[i]; if (r !== 0xffffffff) nm.set(md.subarray(i * mb.stride, (i + 1) * mb.stride), r * mb.stride); }
    if (suffix === '_bind') {
      const br = REMAP[mb.body];
      if (!br) throw new Error('bind before its body mesh: ' + prefix);
      const dv = new DataView(nm.buffer);
      for (let i = 0; i < unique; i++) for (let k = 0; k < 4; k++) {
        const r = br[dv.getUint32(i * mb.stride + k * 4, true)];
        if (r === 0xffffffff) throw new Error('bound to an unused body vertex');
        dv.setUint32(i * mb.stride + k * 4, r, true);
      }
    }
    const em = MeshoptEncoder.encodeVertexBufferLevel(nm, unique, mb.stride, 3, 1);
    const entry = Object.assign({}, mb, { name: prefix + suffix, enc: 'mv', count: unique });
    delete entry.kind;
    push(entry, em);
    console.log(prefix + suffix, 'stride', mb.stride, '->', em.length);
  }
  console.log(prefix, unique, 'verts; vb', ev.length, 'ib', ei.length);
}
const meshes = man.buffers.filter(b => b.name.endsWith('_v') && bufs[b.name.slice(0, -2) + '_i']).map(b => b.name.slice(0, -2));
meshes.forEach(encodeMesh);
// sparse per-vertex records (the corrective shapes): the vertex field follows the new vertex order of its mesh, and
// the records of each shape are sorted by vertex again
function encodeSparse(b) {
  const br = REMAP[b.body];
  if (!br) throw new Error('sparse records before their mesh: ' + b.name);
  const data = new Uint8Array(fs.readFileSync(dir + '/' + b.name + '.raw'));
  const dv = new DataView(data.buffer, data.byteOffset, data.byteLength);
  for (let i = 0; i < b.count; i++) for (let f = 0; f < (b.fields || 1); f++) {
    const r = br[dv.getUint32(i * b.stride + f * 4, true)];
    if (r === 0xffffffff) throw new Error('record on an unused vertex');
    dv.setUint32(i * b.stride + f * 4, r, true);
  }
  const out = new Uint8Array(data.length);
  for (const s of (man.correctives && b.name === 'corr' ? man.correctives.shapes : [{ start: 0, count: b.count }])) {
    const order = Array.from({ length: s.count }, (_, k) => s.start + k).sort((x, y) => dv.getUint32(x * b.stride, true) - dv.getUint32(y * b.stride, true));
    order.forEach((src, k) => out.set(data.subarray(src * b.stride, (src + 1) * b.stride), (s.start + k) * b.stride));
  }
  const e = MeshoptEncoder.encodeVertexBufferLevel(out, b.count, b.stride, 3, 1);
  const entry = Object.assign({ enc: 'mv' }, b); delete entry.kind;
  push(entry, e);
  console.log(b.name, 'records', b.count, 'stride', b.stride, '->', e.length);
}
for (const b of man.buffers) {
  if (b.kind === 'sparse') { encodeSparse(b); continue; }
  if (meshes.some(p => b.name === p + '_v' || b.name === p + '_i' || COMPANIONS.some(s => b.name === p + s))) continue;
  const data = new Uint8Array(fs.readFileSync(dir + '/' + b.name + '.raw'));
  if (b.kind === 'vertex') {
    const e = MeshoptEncoder.encodeVertexBufferLevel(data, b.count, b.stride, 3, 1);
    push(Object.assign({ enc: 'mv' }, b), e);
    console.log(b.name, data.length, '->', e.length);
  } else {
    push(Object.assign({ enc: 'raw' }, b), data);
  }
}
const hjson = Buffer.from(JSON.stringify(header));
const hl = Buffer.alloc(8); hl.write('HDB1', 0); hl.writeUInt32LE(hjson.length, 4);
const hpad = (4 - (hjson.length % 4)) % 4;
const blob = Buffer.concat([hl, hjson, Buffer.alloc(hpad), ...parts]);
const gz = zlib.gzipSync(blob, { level: 9 });
fs.writeFileSync('/home/claude/web/var/model.bin.gz', gz);
fs.writeFileSync('/home/claude/web/var/model.b64', gz.toString('base64'));
console.log('blob', blob.length, 'gz', gz.length, 'b64', Math.ceil(gz.length / 3) * 4);
