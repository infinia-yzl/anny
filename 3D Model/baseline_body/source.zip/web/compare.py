"""Before and after pictures of the corrective shapes in the viewer: each view twice, plain skinning and corrected.

    python3 compare.py out.png '[{"pose": "seated", "view": [yaw, pitch, dist, ty, tz, fov, tx], "label": "Seated"}, ...]' [w h]
"""
import asyncio, sys, json
from playwright.async_api import async_playwright
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, '/home/claude/web')
from shot import serve, route_cdn
import os
ACC = int(os.environ.get('ACC', '16'))
EXTRA = os.environ.get('EXTRA', '')


async def run(items, out, w, h, page='index_dev.html'):
    port = serve()
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=True, args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        pg = await b.new_page(viewport={'width': w, 'height': h})
        logs = []
        pg.on('console', lambda m: logs.append(m.type + ': ' + m.text))
        pg.on('pageerror', lambda e: logs.append('PAGEERROR: ' + str(e)))
        await pg.route('https://cdn.jsdelivr.net/**', route_cdn)
        await pg.goto(f'http://127.0.0.1:{port}/{page}?shot&acc={ACC}{EXTRA}', timeout=120000)
        await pg.wait_for_function('window.__ready === true', timeout=400000)
        # a clean frame: no title, controls or status text over the figure
        await pg.add_style_tag(content='header.title, nav.bar, p.hint, p.status, aside.editor { display: none !important; }')
        rows = []
        for it in items:
            pair = []
            for on in (False, True):
                await pg.evaluate(f'window.setMotion({json.dumps(it["pose"])}, {it.get("t", 0)}, true)')
                await pg.evaluate(f'window.setCorrectives({str(on).lower()})')
                await pg.evaluate(f'window.setView(...{json.dumps(it["view"])})')
                await pg.screenshot(path='/tmp/_cmp.png', timeout=600000)
                pair.append(Image.open('/tmp/_cmp.png').convert('RGB'))
            rows.append((it.get('label', it['pose']), pair))
        for l in logs:
            if 'PAGEERROR' in l or 'error' in l.lower():
                print(l)
        await b.close()
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
    except Exception:
        font = ImageFont.load_default()
    o = Image.new('RGB', (w * 2, h * len(rows)), (20, 20, 22))
    for r, (label, pair) in enumerate(rows):
        for c, im in enumerate(pair):
            d = ImageDraw.Draw(im)
            d.text((12, 10), f'{label}: ' + ('corrected' if c else 'plain skinning'), fill=(240, 240, 240), font=font)
            o.paste(im, (c * w, r * h))
    o.save(out)
    print('saved', out)


if __name__ == '__main__':
    w = int(sys.argv[3]) if len(sys.argv) > 3 else 520
    h = int(sys.argv[4]) if len(sys.argv) > 4 else 620
    asyncio.run(run(json.loads(sys.argv[2]), sys.argv[1], w, h))
